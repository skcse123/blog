<?php require "top.inc.php"; ?>
<body>
<div class="adminlogin">
            < <div class="logo">
                <img src="html/images/download.jpg" alt="" >
                <div class="logo_name"><h3>Milk Island</h3></div>
            </div>
<div class="admin">Welcome <span>Admin</span></div>
<div class="logout">
   <a href="logout.php"><i class="fas fa-sign-out-alt"></i></a>
</div>

</div>
    <div class="sidebar">
        <div class="logo_content">
             <i class="fas fa-bars" id="btn"></i>
        </div> 
   
        <ul class="navlist">
   <li>
       <a href="categories.php">
        <i class="fas fa-columns"></i>
        <span class="links_name">Category</span>
       </a>
       <span class="tooltip">Category</span>
   </li>
   <li>
       <a href="users.php">
        <i class="fas fa-user"></i>
        <span class="links_name">Customers</span>
       </a>
       <span class="tooltip">Customers</span>
   </li>
   <li>
       <a href="products.php">
        <i class="fas fa-shopping-bag"></i>
        <span class="links_name">Products</span>
       </a>
       <span class="tooltip">Products</span>
   </li>
   <li>
       <a href="orders.php">
        <i class="fas fa-shopping-cart"></i>
        <span class="links_name">orders</span>
       </a>
       <span class="tooltip">orders</span>
   </li>
   <li>
       <a href="contact_us.php">
        <i class="fas fa-comments"></i>
        <span class="links_name">messages</span>
       </a>
       <span class="tooltip">messages</span>
   </li>
        </ul>
    </div>
    <div class="home_content "> 
    <div class="row">
      	<div class="col-10">
      		<h2>Manage Category</h2>
      	</div>
      	<div class="col-2">
      		<a href="add_categories.php" class="btn btn-warning btn-sm">Add Product Category</a>
      	</div>
      </div>
      
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
          <tr>
                      <th class="serial">#</th>
                      <th class="avatar">Avatar</th>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Product</th>
                      <th>Quantity</th>
                      <th>Price</th>
                      <th>Status</th>
                   </tr>
          </thead>
          <tbody id="category_list">
                  <tr>
                      <td class="serial">1.</td>
                      <td class="avatar">
                         <div class="round-img">
                            <a href="#"><img class="rounded-circle" src="images/avatar/1.jpg" alt=""></a>
                         </div>
                      </td>
                      <td> #5469 </td>
                      <td> <span class="name">Louis Stanley</span> </td>
                      <td> <span class="product">iMax</span> </td>
                      <td><span class="count">231</span></td>
                      <td><span class="price">rs50</span></td>
                      <td>
                         <span class="badge badge-complete">Complete</span>
                      </td>
                   </tr>
                   <tr>
                      <td class="serial">2.</td>
                      <td class="avatar">
                         <div class="round-img">
                            <a href="#"><img class="rounded-circle" src="images/avatar/2.jpg" alt=""></a>
                         </div>
                      </td>
                      <td> #5468 </td>
                      <td> <span class="name">Gregory Dixon</span> </td>
                      <td> <span class="product">iPad</span> </td>
                      <td><span class="count">250</span></td>
                      <td><span class="price">rs50</span></td>
                      <td>
                         <span class="badge badge-complete">Complete</span>
                      </td>
                   </tr>
                   <tr>
                      <td class="serial">3.</td>
                      <td class="avatar">
                         <div class="round-img">
                            <a href="#"><img class="rounded-circle" src="images/avatar/3.jpg" alt=""></a>
                         </div>
                      </td>
                      <td> #5467 </td>
                      <td> <span class="name">Catherine Dixon</span> </td>
                      <td> <span class="product">SSD</span> </td>
                      <td><span class="count">250</span></td>
                      <td><span class="price">rs50</span></td>
                      <td>
                         <span class="badge badge-complete">Complete</span>
                      </td>
                   </tr>
                   <tr>
                      <td class="serial">4.</td>
                      <td class="avatar">
                         <div class="round-img">
                            <a href="#"><img class="rounded-circle" src="images/avatar/4.jpg" alt=""></a>
                         </div>
                      </td>
                      <td> #5466 </td>
                      <td> <span class="name">Mary Silva</span> </td>
                      <td> <span class="product">Magic Mouse</span> </td>
                      <td><span class="count">250</span></td>
                      <td><span class="price">rs50</span></td>
                      <td>
                         <span class="badge badge-pending">Pending</span>
                      </td>
                   </tr>
                   <tr class=" pb-0">
                      <td class="serial">5.</td>
                      <td class="avatar pb-0">
                         <div class="round-img">
                            <a href="#"><img class="rounded-circle" src="images/avatar/6.jpg" alt=""></a>
                         </div>
                      </td>
                      <td> #5465 </td>
                      <td> <span class="name">Johnny Stephens</span> </td>
                      <td> <span class="product">Monitor</span> </td>
                      <td><span class="count">250</span></td>
                      <td><span class="price">rs50</span></td>
                      <td>
                         <span class="badge badge-complete">Complete</span>
                      </td>
                   </tr>
                </tbody>
             </table>
          
           </div>
       </div>
  
    <?php require "footer.inc.php"; ?>
<?php require "top.inc.php";
if(isset($_GET['type']) && $_GET['type']!=''){
    $type=get_safe_value($con,$_GET['type']);
    if($type=='status'){
        $operation=get_safe_value($con,$_GET['operation']);
        $id=get_safe_value($con,$_GET['id']);
        if($operation=='active'){
            $status='1';
        }else{
            $status='0';
        }
        $update_status_sql = "update category set status ='$status' where id='$id'";
        mysqli_query($con,$update_status_sql);
    }
    if($type=="delete"){
        $id=get_safe_value($con,$_GET['id']);
        $delete_sql="delete from category  where id='$id'";
        mysqli_query($con,$delete_sql);
}
}
$sql ="select * from category order by categories asc";
$res = mysqli_query($con,$sql);



?>
<body>
<div class="adminlogin">
            < <div class="logo">
                <img src="html/images/download.jpg" alt="" >
                <div class="logo_name"><h3>Milk Island</h3></div>
            </div>
<div class="admin">Welcome <span>Admin</span></div>
<div class="logout">
   <a href="logout.php"><i class="fas fa-sign-out-alt"></i></a>
</div>

</div>
    <div class="sidebar">
        <div class="logo_content">
             <i class="fas fa-bars" id="btn"></i>
        </div> 
   
        <ul class="navlist">
   <li>
       <a href="categories.php">
        <i class="fas fa-columns"></i>
        <span class="links_name">Category</span>
       </a>
       <span class="tooltip">Category</span>
   </li>
   <li>
       <a href="users.php">
        <i class="fas fa-user"></i>
        <span class="links_name">Customers</span>
       </a>
       <span class="tooltip">Customers</span>
   </li>
   <li>
       <a href="products.php">
        <i class="fas fa-shopping-bag"></i>
        <span class="links_name">Products</span>
       </a>
       <span class="tooltip">Products</span>
   </li>
   <li>
       <a href="orders.php">
        <i class="fas fa-shopping-cart"></i>
        <span class="links_name">orders</span>
       </a>
       <span class="tooltip">orders</span>
   </li>
   <li>
       <a href="contact_us.php">
        <i class="fas fa-comments"></i>
        <span class="links_name">messages</span>
       </a>
       <span class="tooltip">messages</span>
   </li>
        </ul>
    </div>
    
    <div class="home_content ">
        <div class="container-1">
        <div class="row row2">
      	<div class="col-10">
      		<h2>Manage Category</h2>
      	</div>
      	<div class="col-2">
      		<a href="add_categories.php" class="btn btn-warning btn-sm" id="category">Add Product Category</a>
      	</div>
      </div>
    

  
  <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
          <tr>
                      <th class="serial">#</th>
                      <th>ID</th>
                      <th>Category</th>
                      <th>img</th>
                      <th></th>
                      
                   </tr>
          </thead>
          <tbody id="category_list">
      
                    <?php
                   $i=1;
                   while($row=mysqli_fetch_assoc($res)){
                    ?>
                    <tr>
                   <td class="serial"><?php echo $i; ?></td>
                   <td><?php echo $row['id'];?></td>
                   <td><?php echo $row['categories'];?></td>
                   <td> <img src="<?php echo CATEGORY_IMAGE_SITE_PATH.$row['img']; ?>" alt="no img" height="50px" width=50px></td>
                   <th><?php 
                   if($row['status']==1)
                   {
                       echo "<a  class='btn btn-success btn-sm ' href = '?type=status&operation=deactive&id=". $row['id'] . "'>Active</a>&nbsp";
                   }else{
                    echo "<a class='btn btn-secondary btn-sm' href = '?type=status&operation=active&id=". $row['id'] . "'>Deactive</a>&nbsp";
                   }
                   echo " <a class='btn btn-danger btn-sm'href ='?type=delete&id=" .$row['id']."'>Delete</a>";
                  echo "&nbsp; <a class='btn btn-primary btn-sm'href ='add_categories.php?id=" .$row['id']."'>Edit</a>";
                   ?>
                   </th>
                 </tr>
                 <?php
                 } 
                
                 ?>

                </tbody>
            
                </table>
                         
                  </div>
               </div>
            </div>
            </div>
 </div>
<php require('footer.inc.in');
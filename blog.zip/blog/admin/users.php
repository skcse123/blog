<?php require "top.inc.php";
if(isset($_GET['type']) && $_GET['type']!=''){
    $type=get_safe_value($con,$_GET['type']);
    
    if($type=="delete"){
        $id=get_safe_value($con,$_GET['id']);
        $delete_sql="delete from users  where id='$id'";
        mysqli_query($con,$delete_sql);
   }


}
$sql ="select * from users order by id desc";
$res = mysqli_query($con,$sql);



?>
<body>
<div class="adminlogin">
            < <div class="logo">
                <img src="html/images/download.jpg" alt="" >
                <div class="logo_name"><h3>Milk Island</h3></div>
            </div>
<div class="admin">Welcome <span>Admin</span></div>
<div class="logout">
   <a href="logout.php"><i class="fas fa-sign-out-alt"></i></a>
</div>

</div>
    <div class="sidebar">
        <div class="logo_content">
             <i class="fas fa-bars" id="btn"></i>
        </div> 
   
        <ul class="navlist">
   <li>
       <a href="categories.php">
        <i class="fas fa-columns"></i>
        <span class="links_name">Category</span>
       </a>
       <span class="tooltip">Category</span>
   </li>
   <li>
       <a href="users.php">
        <i class="fas fa-user"></i>
        <span class="links_name">Customers</span>
       </a>
       <span class="tooltip">Customers</span>
   </li>
   <li>
       <a href="products.php">
        <i class="fas fa-shopping-bag"></i>
        <span class="links_name">Products</span>
       </a>
       <span class="tooltip">Products</span>
   </li>
   <li>
       <a href="orders.php">
        <i class="fas fa-shopping-cart"></i>
        <span class="links_name">orders</span>
       </a>
       <span class="tooltip">orders</span>
   </li>
   <li>
       <a href="contact_us.php">
        <i class="fas fa-comments"></i>
        <span class="links_name">messages</span>
       </a>
       <span class="tooltip">messages</span>
   </li>
        </ul>
    </div>
    
    <div class="home_content ">
        <div class="container-contact">
        <div class="row row4">
      	<div class="col-10">
      		<h2>Customer</h2>
      	</div>
      	<!-- <div class="col-2">
      		<a href="add_categories.php" class="btn btn-warning btn-sm" id="category">Add Product Category</a>
      	</div> -->
      </div>
     

  
  <div class="tb-responsive">
        <table class="table table-striped table-sm">
          <thead>
          <tr>
                      <th class="serial">#</th>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Mobile</th>
                      <th>Password</th>
                      <th>Date</th>
                      <th></th>
                      
                   </tr>
          </thead>
          <tbody id="category_list">
                  <?php
                   $i=1;
                   while($row=mysqli_fetch_assoc($res)){
                    ?>
                    <tr>
                   <td class="serial"><?php echo $i; ?></td>
                   <td><?php echo $row['id'];?></td>
                   <td><?php echo $row['name'];?></td>
                   <th><?php echo $row['email'];?></th>
                   <td><?php echo $row['mobile'];?></td>
                   <th><?php echo $row['password'];?></th>
                   <th><?php echo $row['added_on'];?></th>
                   <td>
                   <?php 
                  echo " <a class='btn btn-danger btn-sm'href ='?type=delete&id=" .$row['id']."'>Delete</a>";
                 
                   ?>
                   </td>
                   
                 </tr>
                 <?php
                 } 
                
                 ?>

                </tbody>
            
                </table>
                         
                  </div>
               </div>
            </div>
            </div>
 </div>
<!-- 
<script src="categories.js"></script> -->
 
 
<?php require "footer.inc.php"; ?>  
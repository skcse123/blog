<?php
require('connection.inc.php');
require('function.inc.php');
 $msg='';
if(isset($_POST['submit'])){
  $username=get_safe_value($con,$_POST['username']);
    $password=get_safe_value($con,$_POST['password']);
    $sql="select * from admin_users where username='$username'and password='$password'";
    $res=mysqli_query($con,$sql);
    $count=mysqli_num_rows($res);
    if($count>0){
    $_SESSION['ADMIN_LOGIN']='yes';
    $_SESSION['ADMIN_USERNAME']=$username;
     header('location:dashboard.php');
     die();
     }else{
        $msg="please enter correct login details";
     }
 }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login page</title>
  <link rel="stylesheet" href="login.css">
</head>
<body>
   
    <div class="container">
        <div class="container-body">
            <h1>Sign-In</h1>
            
            <form method="post">
              <div class="form">
                <label for="exampleInput" class="form-label">username</label>
                <input type="text" name="username" class="form-control" id="exampleInput" onclick="myfunction()"required>
              <span>We'll never share your Contact details with anyone else.</span>
              </div>
              <div class="pass">
                <label for="exampleInputPassword1" class="form-label">Password</label>
                <input type="password" name="password" class="form-control" id="exampleInputPassword1" required>
                <span><a href="">Forgot password ?</a></span>
              </div>
             <button type="submit" class="btn " name="submit">login</button>
            </form>
          <div class="field_error">
              <?php echo $msg?>
          </div>
        </div>
    </div>

</body>
</html>
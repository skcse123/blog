<?php 
require('top.inc.php');
?>
<section class="product" id="product">
<?php
$query='';

    $id=mysqli_real_escape_string($con,$_GET['id']);
    if($id!=''){
    $sql="select * from products where category_id={$id}";
    $q=mysqli_query($con,$sql);  
    $num=mysqli_num_rows($q);
    if($num==1){
        $sql="select * from products where status = 1 and category_id={$id} order by id desc ";
        $query=mysqli_query($con,$sql);
        
    }else{
        echo header('location:product.php');
    }
}
$p="select * from category where id={$id}";
$res=mysqli_query($con,$p);
$dataname='';
while($data=mysqli_fetch_array($res)){
  $dataname=$data['categories'];
}  

?>

    <h1 class="heading"><?php echo $dataname;?></h1>

    <div class="box-container">
    <?php
             while($row=mysqli_fetch_assoc($query)){
    ?>
        <div class="box">
           
            <div class="icons">
                <a href="#" class="fas fa-heart"></a>
                <a href="#" class="fas fa-share"></a>
                <a href="#" class="fas fa-eye"></a>
            </div>
            <img src="<?php echo PRODUCT_IMAGE_SITE_PATH.$row['image'];?>" alt="">
            <h3><?php echo $row['name'];?></h3>
            
            <div class="price"><?php echo $row['selling_price'];?><span><?php echo $row['mrp'];?></span> </div>
            <div class="quantity">
                <span>quantity : </span>
                <input type="number" min="1" max="1000" value="1">
                <span>/<?php echo $row['qty'];?></span>
            </div>
            <a href="#" class="btn">add to cart</a>
        </div>

 <?php
            }
        
 ?>
        
    </div>

</section>

<?php require('footer.inc.php')?>
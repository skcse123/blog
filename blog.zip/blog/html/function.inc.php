<?php
function prx(){
 echo'<pre>';
 print_r($arr);
}
function pr(){
echo '<pre>';
print_r($arr);
die();
}

function get_safe_value($con,$str){
    if($str!=''){
        $str=trim($str);
    return mysqli_real_escape_string($con,$str);
    }
}

// function get_category(){
//     $sql="select * from category where status =1";
//    $res=mysqli_query($con,$sql);
//    $data=array();
//    while($row=mysqli_fetch_assoc($res)){
//        $data[]=$row;
//    } 
//    return $data;
// }
?>
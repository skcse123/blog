<section class="footer">

<div class="box-container">

    <div class="box">
        <a href="#" class="logo"><i class="fas fa-shopping-basket"></i>Milk-Island</a>
        <p>As Indians, everyone wants pure and fresh milk and other dairy products everyday. We "Milk-Isand" fullfill our customer demands with pure & fresh products with discount over market price.</p>
        <div class="share">
            <a href="#" class="btn fab fa-facebook-f"></a>
            <a href="#" class="btn fab fa-twitter"></a>
            <a href="#" class="btn fab fa-instagram"></a>
            <a href="#" class="btn fab fa-linkedin"></a>
        </div>
    </div>
    
    <div class="box">
        <h3>our location</h3>
        <div class="links">
            <a href="#">India</a>
            <a href="#">India</a>
            <a href="#">India</a>
            <a href="#">India</a>
            <a href="#">India</a>
        </div>
    </div>

    <div class="box">
        <h3>quick links</h3>
        <div class="links">
            <a href="#">home</a>
            <a href="#">category</a>
            <a href="#">product</a>
            <a href="#">deal</a>
            <a href="#">contact</a>
        </div>
    </div>

    <div class="box">
        <h3>download app</h3>
        <div class="links">
            <a href="#">google play</a>
            <a href="#">window xp</a>
            <a href="#">app store</a>
        </div>
    </div>

</div>

<h1 class="credit"> created by <span> Milk-Island Web Developer </span> | all rights reserved! </h1>

</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="js/script.js"></script>


</body>
</html>
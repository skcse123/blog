<?php
 session_start();
class Controller
{
	
      function send_otp($number,$user)
	{
		// $mobile_number='91'.$number;
        // $apiKey =urlencode("MzM2NzQ3NzU1YTY3NzYzNjVhMzY2MTZkNjk3NDcxN2E=");
        // $Textlocal=new Textlocal(false,false,$apiKey);
        // $numbers = array($mobile_number);
        // $sender = 'TXTLCL';
        // $otp=rand(100000,999999);
        // $_SESSION['session_otp']=$otp;
        // $message="your one time password is".$otp;
        // try{
        //     $response = $Textlocal->sendSms($numbers,$message,$sender);
        //      require_once("verificatin_form.php?code=$user");
        //     exit();
        // }catch(Exception $e){
        //     die('Error:'.$e->getMessage());
        // }
        $apiKey = urlencode('MzM2NzQ3NzU1YTY3NzYzNjVhMzY2MTZkNjk3NDcxN2E=');
	
        // Message details
        $mobile_number='91'.$number;
        $numbers = array($mobile_number);
        $sender = urlencode('TXTLCL');
        $otp=rand(100000,999999);
        $_SESSION['session_otp']=$otp;
        $msg="your one time password is".$otp;
        $message = rawurlencode($msg);
     
        $numbers = implode(',', $numbers);
     
        // Prepare data for POST request
        $data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
     
        // Send the POST request with cURL
        $ch = curl_init('https://api.textlocal.in/send/');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);
        
        // Process your response here
        echo $response;
	}

	function verify_otp($otp){
       if($otp==$_SESSION['session_otp'])
       {
           unset($_SESSION['session_otp']);
           return 'yes';
       }else{
           return "error";
       }
    }
}
?>

<?php
require('top.inc.php');
?>
<section class="top-container">
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam laborum reiciendis enim odio excepturi laudantium repellendus. Ex culpa libero facere tempore accusantium Lorem, ipsum dolor sit amet consectetur adipisicing elit. Qui blanditiis totam, eligendi similique fugit minus est ipsum quod nam id officia unde quo.</p>

</section>

<section class="banner-container">

    <div class="banner">
        <img src="images/Milk.jpg" alt="">
        <div class="content">
            <h3>special offer</h3>
            <p>upto 45% off</p>
            <a href="#" class="btn">check out</a>
        </div>
    </div>

    <div class="banner">
        <img src="images/fruits.jpg" alt="">
        <div class="content">
            <h3>limited offer</h3>
            <p>upto 50% off</p>
            <a href="#" class="btn">check out</a>
        </div>
    </div>

</section>
<section class="top-container">
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam laborum reiciendis enim odio excepturi laudantium repellendus. Ex culpa libero facere tempore accusantium Lorem, ipsum dolor sit amet consectetur adipisicing elit. Qui blanditiis totam, eligendi similique fugit minus est ipsum quod nam id officia unde quo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem quaerat illo eum quae velit voluptatum eaque quam ducimus cupiditate tenetur fugit, earum cum assumenda porro incidunt quidem. Aliquid, repudiandae! Error minima necessitatibus corrupti porro.</p>

</section>

<section class="category" id="category">

    <h1 class="heading">shop by <span>category</span></h1>
    
    <div class="box-container" id="box"> 
      
      </div>

</section>
</div>
<section class="product" id="product" >

    <h1 class="heading">latest <span>products</span></h1>

    <div class="box-container" id="latest">
  

</div> 
</section>

<!-- product section ends -->

<!-- deal section starts  -->

<section class="deal" id="deal">

    <div class="content">

        <h3 class="title">deal of the day</h3>
        <p>Welcome to Our "Deal of the day session", shop with heavy discount on every products on this time and get the purchase coupan also.</p>

        <div class="count-down">
            <div class="box">
                <h3 id="day">00</h3>
                <span>day</span>
            </div>
            <div class="box">
                <h3 id="hour">00</h3>
                <span>hour</span>
            </div>
            <div class="box">
                <h3 id="minute">00</h3>
                <span>minute</span>
            </div>
            <div class="box">
                <h3 id="second">00</h3>
                <span>second</span>
            </div>
        </div>

        <a href="#" class="btn">check the deal</a>

    </div>

</section>

<!-- deal section ends -->

<section class="testimonials">
    <div id="testimonial-cover">
        <h3 class="text-center">What our customer says</h3>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div id="customers-testimonial" class="text-center owl-carousel owl-theme">
                        <div class="testimonial">
                            <img src="images/milkky.jpg" class="image-responsive img-circle"alt="">
                            <div class="test">
                            <blockquote class="text-center">
                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sed eligendi excepturi soluta iusto esse? Eaque harum corrupti obcaecati hic, molestiae dolor. Quibusdam nostrum, quaerat quae incidunt reiciendis ad iste harum animi quos corrupti fugit.</p>
                            </blockquote>
                            <div class="testimonial-author">
                                <p><Strong>Rakesh sahoo</Strong>
                                <span>ceo and founder - google</span>
                                </p>
                            </div>
                            </div>
                        </div>
                        <div class="testimonial">
                            <img src="images/milkky.jpg" class="image-responsive img-circle"alt="">
                            <div class="test">
                            <blockquote class="text-center">
                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sed eligendi excepturi soluta iusto esse? Eaque harum corrupti obcaecati hic, molestiae dolor. Quibusdam nostrum, quaerat quae incidunt reiciendis ad iste harum animi quos corrupti fugit.</p>
                            </blockquote>
                            <div class="testimonial-author">
                                <p><Strong>Rakesh sahoo</Strong>
                                <span>ceo and founder - google</span>
                                </p>
                            </div>
                            </div>
                        </div>
                        <div class="testimonial">
                            <img src="images/milkky.jpg" class="image-responsive img-circle"alt="">
                            <div class="test">
                            <blockquote class="text-center">
                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sed eligendi excepturi soluta iusto esse? Eaque harum corrupti obcaecati hic, molestiae dolor. Quibusdam nostrum, quaerat quae incidunt reiciendis ad iste harum animi quos corrupti fugit.</p>
                            </blockquote>
                            <div class="testimonial-author">
                                <p><Strong>Rakesh sahoo</Strong>
                                <span>ceo and founder - google</span>
                                </p>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- contact section starts  -->




<section class="contact" id="contact" >

    <h1 class="heading"> <span>contact</span> us </h1>

    <form action="">

        <div class="inputBox">
            <input type="text" placeholder="name">
            <input type="email" placeholder="email">
        </div>

        <div class="inputBox">
            <input type="text" placeholder="contact number">
            <input type="text" placeholder="subject">
        </div>

        <textarea placeholder="message" name="" id="" cols="30" rows="10"></textarea>

        <input type="submit" value="send message" class="btn">

    </form>

</section>



<section class="footer">

<div class="box-container">

    <div class="box">
        <a href="#" class="logo"><i class="fas fa-shopping-basket"></i>Milk-Island</a>
        <p>As Indians, everyone wants pure and fresh milk and other dairy products everyday. We "Milk-Isand" fullfill our customer demands with pure & fresh products with discount over market price.</p>
        <div class="share">
            <a href="#" class="btn fab fa-facebook-f"></a>
            <a href="#" class="btn fab fa-twitter"></a>
            <a href="#" class="btn fab fa-instagram"></a>
            <a href="#" class="btn fab fa-linkedin"></a>
        </div>
    </div>
    
    <div class="box">
        <h3>our location</h3>
        <div class="links">
            <a href="#">India</a>
            <a href="#">India</a>
            <a href="#">India</a>
            <a href="#">India</a>
            <a href="#">India</a>
        </div>
    </div>

    <div class="box">
        <h3>quick links</h3>
        <div class="links">
            <a href="#">home</a>
            <a href="#">category</a>
            <a href="#">product</a>
            <a href="#">deal</a>
            <a href="#">contact</a>
        </div>
    </div>

    <div class="box">
        <h3>download app</h3>
        <div class="links">
            <a href="#">google play</a>
            <a href="#">window xp</a>
            <a href="#">app store</a>
        </div>
    </div>

</div>

<h1 class="credit"> created by <span> Milk-Island Web Developer </span> | all rights reserved! </h1>

</section>

<script src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
<script>
$(document).ready(function(){
  

 displayData();
 latestProduct();

  setInterval(() => {
    displayData()   
  }, 30000);

  function displayData(){
         $.ajax({
             url:'manage_index.php',
             type:'post',
             success:function(response){
                 $('#box').html(response);
             }
         });
       }
    
   
    setInterval(() => {
        latestProduct()   
  }, 30000);

         function latestProduct(){
             $.ajax({
                 url:'Latestproduct.php',
                
                 type:"post",
                 success:function(response){
                     $('#latest').html(response);
                 }
             });
         }  
        
    
        
  
      

   $(function(){
       $("#customers-testimonial").owlCarousel({
           items:1,
           autoPlay:true,
           smartSpeed:500,
           loop:true,
           center:true,
          autoplayHoverPause:true,
          responsiveClass:true,
          responsiveRefreshRate:200,
          responsive:{
        0:{
            items:1,
            nav:true
        },
        600:{
            items:1,
            nav:true,
        },
        1000:{
            items:1,
            nav:true,
            
        }
    }
       });
    });
});

</script>

</body>
</html>
<?php


include 'connection.inc.php';
include 'function.inc.php';
include 'controller.php';
$msg = new Controller();
if(isset($_POST['page']))
{
	if($_POST['page'] == 'register')
	{
		if($_POST['action'] == 'check_phone')
		{
		 
        if($_POST[contact]!='' && $_POST['contact'].length==10)
        {
            $contact = get_safe_value($con,$_POST["contact"]);
         $sql="select * from user_table where contact = $contact";
         $res=mysqli_query($con,$sql);
         $count=mysqli_num_rows($res);

		if($count == 0)
			{
				$output = array(
					'success'	=>	true
				);

				echo json_encode($output);
			}
        }
		}

		if($_POST['action'] == 'register')
		{
			
        $user_verification_code = md5(rand());
		$username=get_safe_value($con,$_POST['username']);
        $contact =get_safe_value($con,$_POST['contact']);
        $Password = password_hash(get_safe_value($con,$_POST['password']),PASSWORD_DEFAULT);
       
        $verified='yes';

			$sql="insert into user_table (username,mobile,password,user_verification_code,verified)values('$username','$contact','$Password','$user_verification_code','$verified')";
			$res=mysqli_query($con,$sql);
            
            $msg->send_otp($contact,$user_verification_code);
         }
         if($_POST['page']=='verify')
         {
             if($_POST['action']=='verify')
             {
                 if($_POST['otp']!=''&& $_POST['otp'].length==6)
                 {
                 $otp=get_safe_value($con,$_POST['otp']);
                 $out=$msg->verify_otp($otp);
                 $sql="update user_table set verified = '".$out."' where user_verification_code = '".$_POST['code']."'";
                 $output=array("success"=>$out);
                 echo json_encode($output);
                 }
                 
             }
         }
if($_POST['page'] == 'login')
{
    if($_POST['action'] == 'login')
    {
        $data=get_safe_value($con,$_post['username']);
       
     $sql="select * from user_login where username = '$data'";
     $res=mysqli_query($con,$sql);
     $count=mysqli_num_rows($res);
       if($count>0)
       {
           $result = mysqli_fetch_array($res);
           foreach($result as $row)
           {
               if($row['number_verified'] == 'yes')
               {
                if(password_verify($_POST['password'], $row['password']))
                {
                    $_SESSION['user_id'] = $row['user_id'];
                    $output = array(
                        'success'	=>	true
                    );
                }
                else
                {
                    $output = array(
                        'error'	=>	'Wrong Password'
                    );
                }
            }
            else
            {
                $output = array(
                    'error'		=>	'Mobile number not verified'
                );
            }
        }
    } else
    {
        $output = array(
            'error'		=>	'Wrong username'
        );
    }
               }
           }
        }
       
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   
    <script src="https://cdn.jsdelivr.net/gh/guillaumepotier/Parsley.js@2.9.1/dist/parsley.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
   
  
  <link rel="stylesheet" href="login.css">
</head>
<body>
   
<div class="container ">
      <div class="row ">
        <div class="col-md-3">

        </div>
        <div class="col-md-6" style="margin-top:20px;">
          
          <span id="message">
          <?php
          if(isset($_GET['verified']))
          {
            echo '
            <div class="alert alert-success">
              Your mobile number has been verified, now you can login
            </div>
            ';
          }
          ?>
          </span>
          <div class="card" style="margin:40px auto;">
            <div class="card-header bg-warning" style="text-align:center;">Login</div>
            <div class="card-body">
            
            <form method="post" id="login_form">
              <div class="form-group">
                <label for="username" class="form-label">username</label>
                <input type="text" name="username" class="form-control" id="username">
             
              </div>
              <div class="form-group">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" class="form-control" id="password">
                <span><a href="">Forgot password ?</a></span>
              </div>
              <div class="form-group">
                  <input type="hidden" name="page" value="login" />
                  <input type="hidden" name="action" value="login" />
                  <input type="submit" name="login" id="login" class="btn btn-warning" value="Login" />
                </div>
        </form>
                <div align="center">
                <p>Not yet registered ?<a href="register.php">Register Now</a></p>
              </div>
            </div>
          </div>
            
        </div>
        <div class="col-md-3">

        </div>
      </div>
  </div>

</body>
</html>
<script>

$(document).ready(function(){

  $('#login_form').parsley();

  $('#login_form').on('submit', function(event){
    event.preventDefault();

    $('#username').attr('required', 'required');
$('#password').attr('required', 'required');

    if($('#login_form').parsley().validate())
    {
      $.ajax({
        url:"ajax_action.php",
        method:"POST",
        data:$(this).serialize(),
        dataType:"json",
        beforeSend:function(){
          $('#login').attr('disabled', 'disabled');
          $('#login').val('please wait...');
        },
        success:function(data)
        {
          if(data.success)
          {
            location.href="index.php";
          }
          else
          {
            $('#message').html('<div class="alert alert-danger">'+data.error+'</div>');
          }
          $('#admin_login').attr('disabled', false);
          $('#admin_login').val('Login');
        }
      });
    }

  });

});

</script>
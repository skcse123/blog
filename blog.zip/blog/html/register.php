


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
   <script src="https://cdn.jsdelivr.net/gh/guillaumepotier/Parsley.js@2.9.1/dist/parsley.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <link rel="stylesheet" href="login.css">
</head>
<body>
   
<div class="container">
  		<div class="row">
    		<div class="col-md-3">

    		</div>
    		<div class="col-md-6" style="margin-top:20px;">
    			<span id="message"></span>
      			<div class="card">
            <div class="card-header bg-warning text-center" >Register Now</div>
        			<div class="card-body">
            
            <span class="text-center text-success"><strong>We'll never share your  details with anyone else.</strong></span>
            <form method="post" id="register_form">
              <div class="form-group">
                <label for="username" class="form-label">username</label>
                <input type="text" name="username" class="form-control" id="username" >
            
              </div>
              <div class="form-group">
                <label for="Contact" class="form-label"> Phone Number</label>
                <input type="number" name="contact" class="form-control" id="contact" placeholder="enter phone number"   data-parsley-checkemail data-parsley-checkemail-message='Mobile number already Exists'>
               
              </div>
              <div class="form-group">
                <label for="Password" class="form-label">Password</label>
                <input type="password" name="password" class="form-control" id="password" >
               
              </div>
              <div class="form-group">
                <label for="confirmPassword" class="form-label">Confirm Password</label>
                <input type="password" name="confirmpassword" class="form-control" id="confirmpassword" >
                
              </div>
              <div class="form-group">
                      <input type="hidden" name="page" value="register" />
                      <input type="hidden" name="action" value="register" />
                      <input type="submit" name="register" id="register" class="btn btn-info" value="Register" />
                    </div>
                  </form>
          				<div align="center">
          				<p>Already a user ?<a href="login.php">Login Now</a></p>
          				</div>            
               
                </div>
        			</div>
      			</div>
    		</div>
		    <div class="col-md-3">

		    </div>
  		</div>
	</div>

<script>
$(document).ready(function(){

window.Parsley.addValidator('checkphone', {
  validateString: function(value)
  {
    return $.ajax({
      url:"ajax_action.php",
      method:"POST",
      data:{page:'register', action:'check_phone', phone:value},
      dataType:"json",
      async: false,
      success:function(data)
      {
        
        console.log(data);
        
      }
    });
  }
});


 $('#register_form').parsley();

  $('#register_form').on('submit', function(event){

 event.preventDefault();
 $('#username').attr('required', 'required');
 $('#username').attr('data-parsley-pattern', '^[a-zA-Z ]+$');
 
 $('#contact').attr('required', 'required');
 $('#contact').attr('data-parsley-pattern', '^[0-9]+$');
 


  $('#password').attr('required', 'required');

  $('#confirmpassword').attr('required', 'required');

  $('#confirmpassword').attr('data-parsley-equalto', '#password');


 



  if($('#register_form').parsley().isValid())
  {
    $.ajax({
      url:"ajax_action.php",
      method:"POST",
      data:new FormData(this),
      dataType:"json",
      contentType:false,
      cache:false,
      processData:false,
    
    
   });
  }

});

});

</script>
</body>
</html>